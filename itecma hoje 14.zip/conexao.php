<?php 

	
	$hostname = "localhost";
	$username = "root";
	$passe = "";
	$dbname = "dbwebhost";
	
	$conexao = mysqli_connect($hostname, $username, $passe, $dbname);

 ?>