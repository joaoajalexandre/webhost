<?php
session_start();
// Conectar ao banco de dados com PDO
include("conexao.php");

try {
    // Consulta para pegar as mensagens
    $sql = "SELECT id_cliente, nome, mensagem, TIMESTAMPDIFF(MINUTE, data_envio, NOW()) AS minutos_atras 
            FROM tb_mensagens 
            ORDER BY data_envio DESC";

    // Preparar a consulta
    $stmt = $conn->prepare($sql);

    // Executar a consulta
    $stmt->execute();

    // Verificar se há resultados
    if ($stmt->rowCount() > 0) {
        $mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $mensagens = [];
    }

} catch (PDOException $e) {
    // Caso haja erro na execução da consulta
    echo "Erro: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <meta charset="utf-8">
    <title>Clientes</title>
    <meta
      content="width=device-width, initial-scale=1.0, shrink-to-fit=no"
      name="viewport"
    />
    <link
      rel="icon"
      href="../img/logo.png"
      type="image/x-icon"
    />

    <!-- Fonts and icons -->
    <script src="./assets/js/plugin/webfont/webfont.min.js"></script>
    <script>
      WebFont.load({
        google: { families: ["Public Sans:300,400,500,600,700"] },
        custom: {
          families: [
            "Font Awesome 5 Solid",
            "Font Awesome 5 Regular",
            "Font Awesome 5 Brands",
            "simple-line-icons",
          ],
          urls: ["./assets/css/fonts.min.css"],
        },
        active: function () {
          sessionStorage.fonts = true;
        },
      });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="./assets/css/plugins.min.css" />
    <link rel="stylesheet" href="./assets/css/kaiadmin.min.css" />

    <!-- CSS Just for demo purpose, don't include it in your project -->
    <link rel="stylesheet" href="./assets/css/demo.css" />
  </head>
  <body>
    <div class="wrapper">
      <!-- Sidebar -->
      <?php
        include("sidebar.php");
        ?>
      <!-- End Sidebar -->

      <div class="main-panel">
        <div class="main-header">
          <div class="main-header-logo">
            <!-- Logo Header -->
            <div class="logo-header" data-background-color="dark">
              <a href="./index.php" class="logo">
                <img
                  src="./assets/img/kaiadmin/logo_light.svg"
                  alt="navbar brand"
                  class="navbar-brand"
                  height="20"
                />
              </a>
              <div class="nav-toggle">
                <button class="btn btn-toggle toggle-sidebar">
                  <i class="gg-menu-right"></i>
                </button>
                <button class="btn btn-toggle sidenav-toggler">
                  <i class="gg-menu-left"></i>
                </button>
              </div>
              <button class="topbar-toggler more">
                <i class="gg-more-vertical-alt"></i>
              </button>
            </div>
            <!-- End Logo Header -->
          </div>
          <!-- Navbar Header -->
          <?php

include("./navbar.php");

?>
            <!-- End Navbar -->
        </div>

        <div class="container">
          <div class="page-inner">
           
            <div class="row">
            <div class="col-md-10">
  <div class="card card-round">
    <div class="card-body">
      <div class="card-head-row card-tools-still-right">
        <div class="card-title">Mensagens</div>
        <div class="card-tools">
          <div class="dropdown">
            <button class="btn btn-icon btn-clean me-0" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-ellipsis-h"></i>
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
              <a class="dropdown-item" href="#">Action</a>
              <a class="dropdown-item" href="#">Another action</a>
              <a class="dropdown-item" href="#">Something else here</a>
            </div>
          </div>
        </div>
      </div>

      <div class="card-list py-4">
    <?php foreach ($mensagens as $mensagem): ?>
        <div class="item-list">
            <div class="avatar">
                <!-- Avatar é baseado nas iniciais ou imagem -->
                <span class="avatar-title rounded-circle border border-white">
                    <?php echo strtoupper(substr($mensagem['nome'], 0, 2)); ?>
                </span>
            </div>
            <div class="info-user ms-3">
                <div class="username"><?php echo htmlspecialchars($mensagem['nome']); ?></div>

                <!-- Verifica se a mensagem é maior que 100 caracteres -->
                <?php if (strlen($mensagem['mensagem']) > 100): ?>
                    <!-- Exibe a versão encurtada -->
                    <div class="status">
                        <span class="short-msg"><?php echo htmlspecialchars(substr($mensagem['mensagem'], 0, 100)); ?>...</span>
                        <span class="full-msg" style="display: none;"><?php echo htmlspecialchars($mensagem['mensagem']); ?></span>
                        <a href="#" class="read-more" onclick="toggleMessage(this); return false;">Ler mais</a>
                    </div>
                <?php else: ?>
                    <!-- Exibe a mensagem completa se for pequena -->
                    <div class="status"><?php echo htmlspecialchars($mensagem['mensagem']); ?></div>
                <?php endif; ?>
            </div>
            <form action="enviar_ver_mensagens.php" method="get" style="display:inline;">
    <input type="hidden" name="id_cliente" value="<?php echo htmlspecialchars($mensagem['id_cliente']); ?>" />
    <button type="submit" class="btn btn-icon btn-link op-8 me-1">
        <i class="far fa-envelope"></i>
    </button>
</form>

            <button class="btn btn-icon btn-link btn-danger op-8">
                <i class="fas fa-ban"></i>
            </button>
        </div>
    <?php endforeach; ?>
</div>

<script>
    function toggleMessage(link) {
        var shortMsg = link.parentElement.querySelector('.short-msg');
        var fullMsg = link.parentElement.querySelector('.full-msg');

        if (shortMsg.style.display === "none") {
            shortMsg.style.display = "inline";
            fullMsg.style.display = "none";
            link.innerHTML = "Ler mais";
        } else {
            shortMsg.style.display = "none";
            fullMsg.style.display = "inline";
            link.innerHTML = "Ler menos";
        }
    }
</script>

    </div>
  </div>
</div>
        </div>

        <footer class="footer">
          <div class="container-fluid d-flex justify-content-between">
            <nav class="pull-left">
              <ul class="nav">
                <li class="nav-item">
                  <a class="nav-link" href="#">
                    Empresa
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#"> ajuda </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#"> Licenças </a>
                </li>
              </ul>
            </nav>
            <div class="copyright">
              2025, feito com <i class="fa fa-heart heart text-danger"></i> por
              <a href="#">Empresa</a>
            </div>
            <div>
              Distribuido por
              <a target="_blank" href="#">empresa</a>.
            </div>
          </div>
        </footer>
      </div>
    </div>
    <!--   Core JS Files   -->
    <script src="./assets/js/core/jquery-3.7.1.min.js"></script>
    <script src="./assets/js/core/popper.min.js"></script>
    <script src="./assets/js/core/bootstrap.min.js"></script>

    <!-- jQuery Scrollbar -->
    <script src="./assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
    <!-- Datatables -->
    <script src="./assets/js/plugin/datatables/datatables.min.js"></script>
    <!-- Kaiadmin JS -->
    <script src="./assets/js/kaiadmin.min.js"></script>
    <!-- Kaiadmin DEMO methods, don't include it in your project! -->
    <script src="./assets/js/setting-demo2.js"></script>
    <script>
      $(document).ready(function () {
        $("#basic-datatables").DataTable({});

        $("#multi-filter-select").DataTable({
          pageLength: 5,
          initComplete: function () {
            this.api()
              .columns()
              .every(function () {
                var column = this;
                var select = $(
                  '<select class="form-select"><option value=""></option></select>'
                )
                  .appendTo($(column.footer()).empty())
                  .on("change", function () {
                    var val = $.fn.dataTable.util.escapeRegex($(this).val());

                    column
                      .search(val ? "^" + val + "$" : "", true, false)
                      .draw();
                  });

                column
                  .data()
                  .unique()
                  .sort()
                  .each(function (d, j) {
                    select.append(
                      '<option value="' + d + '">' + d + "</option>"
                    );
                  });
              });
          },
        });

        // Add Row
        $("#add-row").DataTable({
          pageLength: 5,
        });

        var action =
          '<td> <div class="form-button-action"> <button type="button" data-bs-toggle="tooltip" title="" class="btn btn-link btn-primary btn-lg" data-original-title="Edit Task"> <i class="fa fa-edit"></i> </button> <button type="button" data-bs-toggle="tooltip" title="" class="btn btn-link btn-danger" data-original-title="Remove"> <i class="fa fa-times"></i> </button> </div> </td>';

        $("#addRowButton").click(function () {
          $("#add-row")
            .dataTable()
            .fnAddData([
              $("#addName").val(),
              $("#addPosition").val(),
              $("#addOffice").val(),
              action,
            ]);
          $("#addRowModal").modal("hide");
        });
      });
    </script>
  </body>
</html>
